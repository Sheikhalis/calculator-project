#! /usr/bin/env node
import inquirer from "inquirer";
import chalk from "chalk";
import chalkAnimation from "chalk-animation";


 const sleep=()=>{
     return new Promise((res)=>{
     setTimeout(res,2000);
    })
}
async function welcome (){
  let rainbow = chalkAnimation.rainbow('Lets start calculation');//start
  await sleep()
  rainbow.stop();
  console.log(`                          
  ___  _____   _____ _ __  
 / __|/ _ \ \ / / _ \ '_ \ 
 \__ \  __/\ V /  __/ | | |
 |___/\___| \_/ \___|_| |_|
                           `);
 // console.log(`${rainbow})is fine`);
}
await welcome();
async function askQuestion (){
  const answers= await  inquirer
  .prompt([

{
  type:"list",
  name: "operator",
  message : "which operation do you perform? \n",
    choices:["Addition","Subtraction","Multiplication","Division"]   
},
{
  type:"number",
  name:"num1",
  message:"Enter number 1:",
},
{
 type:"number",
  name:"num2",
  message:"Enter number 2:",
}
])

     if
        (answers.operator=="Addition"){
            console.log(chalk.green(`${answers.num1} + ${answers.num2} = ${answers.num1 + answers.num2}`));
        }
        else if
        (answers.operator=="Subtraction"){
            console.log(chalk.green(`${answers.num1} - ${answers.num2} = ${answers.num1 - answers.num2}`));  
        }
        else if
        (answers.operator=="Multiplication"){
            console.log(chalk.green(`${answers.num1} * ${answers.num2} = ${answers.num1 * answers.num2}`));  
        }
        else if
        (answers.operator=="Division"){
            console.log(chalk.green(`${answers.num1} / ${answers.num2} = ${answers.num1 / answers.num2}`));   
        } 
 };
async function startAgain(){
    do{
        await askQuestion();
       var again = await inquirer
        .prompt({
            type:"input",
            name:"restart",
            message :"Do you want to continue? Press y or n:"
        })
   }while (again.restart =='y' || again.restart=='Y'|| again.restart=='yes'|| again.restart=='Yes')
}
startAgain();
